#!/bin/bash
BASEDIR="$( cd "$( dirname "${0}" )" && pwd )"

echo ${1}
NAMESPACE="telefonica-cem-mbb-prod"
if [ "$1" != "" ]
then
    NAMESPACE="${1}"
fi

kubectl create namespace ${NAMESPACE}


kubectl -n "${NAMESPACE}" apply -f "${BASEDIR}/sftp.yaml"
